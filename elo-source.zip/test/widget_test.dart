import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:elo/main.dart';
import 'package:elo/store.dart';
import 'package:elo/domain.dart';

import 'domain_test.dart' show MemoryStorage;

void main() {
  testWidgets(
    'create and complete task at iPhone width persists after reopening',
    (tester) async {
      tester.view.physicalSize = const Size(393, 852);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final mem = MemoryStorage();
      final store = ELOStore(mem);
      await store.load();
      await store.restore(AppData(started: true));
      await tester.pumpWidget(EloApp(store: store));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Hoje'));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('Adicionar ao meu dia'));
      await tester.tap(find.text('Adicionar ao meu dia'));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byType(TextFormField).first,
        'Testar ELO no iPhone',
      );
      await tester.dragUntilVisible(
        find.text('Salvar'),
        find.byType(Scrollable).last,
        const Offset(0, -250),
      );
      await tester.tap(find.text('Salvar'));
      await tester.pumpAndSettle();
      expect(store.data.tasks.single.title, 'Testar ELO no iPhone');
      await tester.ensureVisible(find.byType(Checkbox).first);
      await tester.tap(find.byType(Checkbox).first);
      await tester.pumpAndSettle();
      final reopened = ELOStore(mem);
      await reopened.load();
      expect(reopened.data.tasks.single.completedAt, isNotNull);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('dream view fits 393px without overflow', (tester) async {
    tester.view.physicalSize = const Size(393, 852);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final store = ELOStore(MemoryStorage());
    await store.load();
    await store.restore(AppData.demo());
    await tester.pumpWidget(EloApp(store: store));
    await tester.pumpAndSettle();
    expect(find.text('25%'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}

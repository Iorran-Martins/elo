import 'package:flutter_test/flutter_test.dart';
import 'package:elo/domain.dart';
import 'package:elo/store.dart';

class MemoryStorage implements DataStorage {
  final values = <String, String>{};
  bool fail = false;
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async {
    if (fail) throw StateError('disk full');
    values[key] = value;
  }
}

void main() {
  test('demo roundtrip and progress', () {
    final d = AppData.demo(DateTime(2026, 9, 12));
    final copy = AppData.decode(d.encode());
    expect(copy.progress(copy.dreamSteps(copy.dreams.single.id)), .25);
  });
  test('deleting goal preserves tasks without dangling links', () {
    final d = AppData.demo();
    d.deleteGoal(d.goals.single.id);
    d.validate();
    expect(d.tasks.length, 3);
    expect(d.tasks.every((t) => t.stepId == null), true);
    expect(d.steps, isEmpty);
  });
  test('habit resets daily and reversal removes only that day', () {
    final a = DateTime(2026, 9, 12);
    final b = a.add(const Duration(days: 1));
    final d = AppData.demo(a);
    final id = d.tasks.last.id;
    d.toggleTask(id, a);
    expect(d.tasks.last.doneOn(a), true);
    expect(d.tasks.last.doneOn(b), false);
    d.toggleTask(id, b);
    d.toggleTask(id, a);
    expect(d.tasks.last.doneOn(b), true);
    expect(d.history.where((h) => h.sourceId == id).length, 1);
  });
  test('task completion does not falsely complete a milestone', () {
    final d = AppData.demo();
    d.toggleTask(d.tasks.first.id, DateTime.now());
    expect(d.progress(d.steps), .25);
  });
  test('calendar days include correct dates only', () {
    final d = AppData(
      started: true,
      tasks: [PlanTask(title: 'Tomorrow', due: DateTime(2026, 9, 13))],
    );
    expect(d.onDay(DateTime(2026, 9, 12)), isEmpty);
    expect(d.onDay(DateTime(2026, 9, 13)).length, 1);
  });
  test('failed save preserves previous in-memory data', () async {
    final mem = MemoryStorage();
    final s = ELOStore(mem);
    await s.load();
    await s.restore(AppData.demo());
    final before = s.data.encode();
    mem.fail = true;
    await expectLater(s.change((d) => d.tasks.clear()), throwsStateError);
    expect(s.data.encode(), before);
  });
  test('corrupt data is preserved and cannot be overwritten', () async {
    final mem = MemoryStorage()..values[ELOStore.dataKey] = 'broken';
    final s = ELOStore(mem);
    await s.load();
    expect(s.loadError, isNotNull);
    await expectLater(s.change((d) => d.started = true), throwsStateError);
    expect(mem.values[ELOStore.dataKey], 'broken');
  });
  test('stale window refuses to overwrite a newer save', () async {
    final mem = MemoryStorage();
    final a = ELOStore(mem), b = ELOStore(mem);
    await a.load();
    await b.load();
    await a.restore(AppData.demo());
    await expectLater(b.change((d) => d.started = true), throwsStateError);
  });
  test('recover validates and restores last backup', () async {
    final mem = MemoryStorage()
      ..values[ELOStore.dataKey] = 'broken'
      ..values[ELOStore.backupKey] = AppData.demo().encode();
    final s = ELOStore(mem);
    await s.load();
    await s.recover();
    expect(s.loadError, isNull);
    expect(s.data.dreams.length, 1);
    expect(mem.values.values, contains('broken'));
  });
  test('invalid references in backups rejected', () {
    final d = AppData.demo();
    d.tasks.first.stepId = 'missing';
    expect(() => AppData.decode(d.encode()), throwsFormatException);
  });
  test('calendar exports UTC and escaped text', () {
    final s = calendarEvent(
      PlanTask(title: 'Meet, plan; ship', due: DateTime.utc(2026, 9, 12, 12)),
    );
    expect(s, contains('DTSTART:20260912T120000Z'));
    expect(s, contains(r'SUMMARY:Meet\, plan\; ship'));
    expect(s, contains('BEGIN:VALARM'));
  });
}

import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';

// Run after flutter build web. Assets and engine are served from the same origin.
void main() {
  final root = Directory('build/web');
  final files =
      root
          .listSync(recursive: true)
          .whereType<File>()
          .where(
            (f) =>
                !f.path.endsWith('sw.js') &&
                !f.path.endsWith('.map') &&
                !f.path.contains('skwasm') &&
                !f.path.endsWith('.nojekyll'),
          )
          .toList()
        ..sort((a, b) => a.path.compareTo(b.path));
  final paths = files
      .map((f) => f.path.substring(root.path.length + 1).replaceAll('\\', '/'))
      .toList();
  final hash = sha256
      .convert(files.expand((f) => f.readAsBytesSync()).toList())
      .toString()
      .substring(0, 16);
  File('build/web/sw.js').writeAsStringSync('''
const PREFIX='elo-'+new URL('./',self.location.href).pathname+'-';
const CACHE=PREFIX+'$hash';
const ASSETS=${jsonEncode(paths)};
const ROOT=new URL('./',self.location.href);
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(ASSETS.map(path=>new Request(new URL(path,ROOT),{cache:'reload'})));})()));
self.addEventListener('message',event=>{if(event.data==='ACTIVATE')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys()){if(key.startsWith(PREFIX)&&key!==CACHE)await caches.delete(key);}await self.clients.claim();})()));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==ROOT.origin||!url.pathname.startsWith(ROOT.pathname))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE);if(event.request.mode==='navigate')return (await cache.match(new URL('index.html',ROOT)))||fetch(event.request);return (await cache.match(event.request,{ignoreSearch:true}))||fetch(event.request);})());
});
''');
  File('build/web/.nojekyll').writeAsStringSync('');
  stdout.writeln('Offline cache: ${paths.length} files, version $hash');
}

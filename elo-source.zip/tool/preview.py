from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'build'/'web'
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
 def do_GET(self):
  if self.path=='/':self.send_response(302);self.send_header('Location','/elo/');self.end_headers();return
  if self.path.startswith('/elo/'):self.path=self.path[4:]
  return super().do_GET()
ThreadingHTTPServer(('127.0.0.1',4173),Handler).serve_forever()

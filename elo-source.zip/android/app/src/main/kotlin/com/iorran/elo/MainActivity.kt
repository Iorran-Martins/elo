package com.iorran.elo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

# ELO — seu próximo capítulo

Organizador pessoal em Flutter 3.47.4 / Dart 3.13.3. Interface em português, tema escuro âmbar, armazenamento local e suporte web instalável no iPhone.

## Usar no iPhone 15

Após publicar no GitHub Pages, abra o endereço HTTPS no **Safari**, toque em **Compartilhar → Adicionar à Tela de Início → Adicionar**. Abra uma vez com internet e aguarde a confirmação de disponibilidade offline.

Esta entrega é Flutter Web (PWA). Não é um arquivo IPA nem uma publicação na App Store. Uma instalação iOS nativa exige compilação em macOS e assinatura Apple. O projeto iOS está incluído, mas não foi compilado neste Windows. Android também está preparado, mas não foi validado em aparelho.

## Funcionalidades

- Tarefas, compromissos e hábitos diários; prioridade, categoria, notas, data e horário.
- Meu dia, pendências, itens sem prazo e calendário.
- Sonhos → objetivos semanais/mensais → etapas → tarefas vinculadas.
- Progresso real por etapas e histórico de conquistas.
- Edição e exclusão com preservação das tarefas ao remover vínculos.
- Backup JSON exportável/importável e cópia de recuperação antes de cada gravação.
- Instalação web, recursos locais e cache offline versionado.
- Exportação de compromisso `.ics` para importar no Calendário. Não há push nem notificações automáticas com a PWA fechada. A importação do calendário precisa ser confirmada no aparelho.

Os exemplos são opcionais. Nenhum registro pessoal é enviado ao GitHub. Não há servidor de dados nem sincronização entre dispositivos. Safari e a versão da Tela de Início podem manter áreas de armazenamento diferentes: use backup/importação se necessário. Limpar dados do navegador pode apagar os registros.

## Desenvolver no VS Code

1. Instale o Flutter estável 3.47.4 e a extensão oficial Flutter (Dart-Code.flutter).
2. Abra esta pasta no VS Code.
3. Execute `flutter pub get` e `flutter run -d chrome`.
4. Use F5 com a configuração **ELO · navegador**.

A configuração local `.vscode/settings.json` aponta para o SDK instalado nesta máquina; ela não é publicada. Em outro computador, selecione o SDK pelo VS Code.

## Verificar e gerar

```sh
flutter analyze
flutter test
flutter build web --release --base-href /elo/ --no-web-resources-cdn
dart run tool/build_offline.dart
```

Use `/NOME-DO-REPOSITORIO/` no lugar de `/elo/` se o nome mudar. `build/web` é o pacote estático publicável. O script offline deve rodar após cada compilação.

Prévia local: `python tool/preview.py`, endereço `http://127.0.0.1:4173/elo/`.

## GitHub Pages

O fluxo `.github/workflows/pages.yml` verifica, testa, compila e publica a cada envio à branch `main`. No repositório, configure **Settings → Pages → Source → GitHub Actions**. O código pode ser baixado por **Code → Download ZIP**. No iPhone, a instalação é pelo Safari, não pelo ZIP do código.

## Estrutura

- `lib/domain.dart`: modelos, vínculos, progresso, hábitos e exportação de calendário.
- `lib/store.dart`: persistência, backup e recuperação.
- `lib/main.dart`: navegação, telas e formulários.
- `lib/theme.dart`: tema, vidro e indicador de progresso.
- `lib/platform/`: exportação específica para web/nativo.
- `test/`: testes de domínio, persistência e interação.
- `web/`: instalação, ícones e inicialização web.

## Limites da primeira versão

O planejamento armazena período e data-alvo, mas ainda não possui recorrência de objetivos nem reorganização por arrastar. Hábitos são diários. Não há sincronização ou migração automática do antigo armazenamento Jarvis; backups desta versão usam o formato `elo.flutter`.

## Créditos

Paisagem e ícone originais gerados para o projeto. Roboto distribuído com o Flutter; licença em `assets/fonts/roboto_license.txt`. Ícones Material. Dependências e versões exatas em `pubspec.lock`.

import 'dart:js_interop';

import 'package:web/web.dart' as web;

Future<void> saveText(String name, String content, String mime) async {
  final blob = web.Blob([content.toJS].toJS, web.BlobPropertyBag(type: mime));
  final url = web.URL.createObjectURL(blob);
  final anchor = web.HTMLAnchorElement()
    ..href = url
    ..download = name;
  web.document.body!.append(anchor);
  anchor.click();
  anchor.remove();
  Future<void>.delayed(
    const Duration(seconds: 30),
    () => web.URL.revokeObjectURL(url),
  );
}

bool get installed =>
    web.window.matchMedia('(display-mode: standalone)').matches;
Future<bool> requestPersistence() async =>
    (await web.window.navigator.storage.persist().toDart).toDart;

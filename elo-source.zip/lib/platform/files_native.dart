import 'dart:convert';
import 'dart:typed_data';

import 'package:share_plus/share_plus.dart';

Future<void> saveText(String name, String content, String mime) async {
  await SharePlus.instance.share(
    ShareParams(
      files: [
        XFile.fromData(
          Uint8List.fromList(utf8.encode(content)),
          mimeType: mime,
          name: name,
        ),
      ],
      fileNameOverrides: [name],
    ),
  );
}

bool get installed => true;
Future<bool> requestPersistence() async => true;

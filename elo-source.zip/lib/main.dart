import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:file_selector/file_selector.dart';

import 'domain.dart';
import 'store.dart';
import 'theme.dart';
import 'platform/files.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(EloApp(store: ELOStore(PreferencesStorage())..load()));
}

class EloApp extends StatelessWidget {
  final ELOStore store;
  const EloApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ELO',
    debugShowCheckedModeBanner: false,
    theme: eloTheme(),
    locale: const Locale('pt', 'BR'),
    supportedLocales: const [Locale('pt', 'BR')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: Home(store: store),
  );
}

class Home extends StatefulWidget {
  final ELOStore store;
  const Home({super.key, required this.store});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late final SemanticsHandle semanticsHandle;
  @override
  void initState() {
    super.initState();
    semanticsHandle = SemanticsBinding.instance.ensureSemantics();
  }

  @override
  void dispose() {
    semanticsHandle.dispose();
    super.dispose();
  }

  int tab = 2;
  DateTime day = dayStart(DateTime.now());
  ELOStore get store => widget.store;
  AppData get data => store.data;
  Future<void> action(Future<void> Function() fn) async {
    try {
      await fn();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Bad state: ', ''))),
        );
      }
    }
  }

  Future<bool> confirm(String text) async =>
      await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Confirmar alteração'),
          content: Text(text),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Confirmar'),
            ),
          ],
        ),
      ) ??
      false;
  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      if (store.loading) {
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      }
      if (store.loadError != null) {
        return Scaffold(
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(store.loadError!),
                  const SizedBox(height: 24),
                  PrimaryButton(
                    'Recuperar cópia anterior',
                    onPressed: () => action(store.recover),
                  ),
                  TextButton(
                    onPressed: () => action(() async {
                      await saveText(
                        'elo-original.json',
                        await store.original() ?? '',
                        'application/json',
                      );
                    }),
                    child: const Text('Exportar original'),
                  ),
                  TextButton(
                    onPressed: store.load,
                    child: const Text('Tentar novamente'),
                  ),
                ],
              ),
            ),
          ),
        );
      }
      if (!data.started) {
        return Scaffold(
          body: SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.all(28),
                  children: [
                    const Eyebrow('ELO · seu organizador pessoal'),
                    const SizedBox(height: 24),
                    const Text(
                      'Seu próximo\ngrande capítulo.',
                      style: TextStyle(
                        fontSize: 43,
                        fontWeight: FontWeight.w300,
                        height: 1.1,
                      ),
                    ),
                    const Horizon(0),
                    const Text(
                      'Conecte o que você faz hoje com a vida que quer construir.',
                      style: TextStyle(color: muted, fontSize: 17, height: 1.6),
                    ),
                    const SizedBox(height: 28),
                    PrimaryButton(
                      'Começar meu capítulo',
                      onPressed: () =>
                          action(() => store.change((d) => d.started = true)),
                    ),
                    TextButton(
                      onPressed: () =>
                          action(() => store.restore(AppData.demo())),
                      child: const Text('Explorar com exemplos'),
                    ),
                    const Text(
                      'Seus dados ficam neste aparelho. Exporte backups em Ajustes.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 12, 16, 0),
                    child: Row(
                      children: [
                        const Expanded(child: Eyebrow('E L O')),
                        IconButton(
                          tooltip: 'Histórico de conquistas',
                          onPressed: history,
                          icon: const Icon(Icons.workspace_premium_outlined),
                        ),
                        IconButton(
                          tooltip: 'Ajustes e backup',
                          onPressed: settings,
                          icon: const Icon(Icons.tune_rounded),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: AnimatedSwitcher(
                      duration: MediaQuery.disableAnimationsOf(context)
                          ? Duration.zero
                          : const Duration(milliseconds: 220),
                      child: ListView(
                        key: ValueKey(tab),
                        padding: const EdgeInsets.fromLTRB(24, 14, 24, 24),
                        children: tab == 0
                            ? today()
                            : tab == 1
                            ? planning()
                            : dreams(),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
                    child: Glass(
                      radius: 32,
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        children: [
                          nav(0, 'Hoje', Icons.wb_sunny_outlined),
                          nav(1, 'Planejar', Icons.calendar_month_outlined),
                          nav(2, 'Sonhos', Icons.auto_awesome_outlined),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
  );
  Widget nav(int index, String label, IconData icon) => Expanded(
    child: TextButton(
      onPressed: () => setState(() => tab = index),
      style: TextButton.styleFrom(
        foregroundColor: tab == index ? amber : muted,
        backgroundColor: tab == index
            ? amber.withValues(alpha: .1)
            : Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 23),
          const SizedBox(height: 5),
          Text(label, style: const TextStyle(fontSize: 12)),
        ],
      ),
    ),
  );
  Widget heading(String title, String subtitle) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        title,
        style: const TextStyle(
          fontSize: 36,
          fontWeight: FontWeight.w300,
          height: 1.12,
        ),
      ),
      const SizedBox(height: 12),
      Text(subtitle, style: const TextStyle(color: muted, height: 1.5)),
      const SizedBox(height: 24),
    ],
  );
  List<Widget> dreams() => [
    const Eyebrow('O que te move'),
    const SizedBox(height: 14),
    const Text(
      'Seu próximo\ngrande capítulo.',
      style: TextStyle(
        fontSize: 39,
        fontWeight: FontWeight.w300,
        height: 1.08,
        letterSpacing: -1.2,
      ),
    ),
    if (data.dreams.isEmpty)
      const EmptyMessage(
        'O que você quer conquistar?',
        'Dê um nome ao seu sonho e transforme-o em etapas.',
      ),
    for (final dream in data.dreams) ...[
      const SizedBox(height: 8),
      Horizon(data.progress(data.dreamSteps(dream.id))),
      Row(
        children: [
          Expanded(
            child: Text(
              dream.title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w300),
            ),
          ),
          IconButton(
            tooltip: 'Editar sonho',
            onPressed: () => edit('dream', dream),
            icon: const Icon(Icons.more_horiz),
          ),
        ],
      ),
      if (dream.why.isNotEmpty)
        Text(
          dream.why,
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted, height: 1.5),
        ),
      const SizedBox(height: 18),
      for (final step in data.dreamSteps(dream.id)) ...[
        Glass(
          active:
              step.id ==
              data
                  .dreamSteps(dream.id)
                  .where((s) => s.completedAt == null)
                  .firstOrNull
                  ?.id,
          radius: 22,
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
          child: Row(
            children: [
              Checkbox(
                shape: const CircleBorder(),
                value: step.completedAt != null,
                onChanged: (_) => action(
                  () => store.change(
                    (d) => d.toggleStep(step.id, DateTime.now()),
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  step.title,
                  style: TextStyle(
                    fontSize: 15,
                    color: step.completedAt == null ? ink : muted,
                    decoration: step.completedAt == null
                        ? null
                        : TextDecoration.lineThrough,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Editar etapa',
                onPressed: () => edit('step', step),
                icon: const Icon(Icons.more_horiz, size: 18),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
      ],
      const SizedBox(height: 12),
      PrimaryButton(
        'Dar o próximo passo',
        icon: Icons.arrow_forward,
        onPressed: () {
          final next = data
              .dreamSteps(dream.id)
              .where((s) => s.completedAt == null)
              .firstOrNull;
          if (next != null) {
            edit('task', null, next.id);
          } else {
            edit('goal', null, dream.id);
          }
        },
      ),
      TextButton(
        onPressed: () => edit('goal', null, dream.id),
        child: const Text('Adicionar objetivo'),
      ),
      const SizedBox(height: 20),
    ],
    TextButton.icon(
      onPressed: () => edit('dream'),
      icon: const Icon(Icons.add),
      label: const Text('Adicionar sonho'),
    ),
  ];
  Widget goalCard(Goal goal) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(goal.title),
          subtitle: Text(
            '${goal.period == 'week'
                ? 'Semana'
                : goal.period == 'month'
                ? 'Mês'
                : 'Horizonte'} · ${shortDate(goal.target)}',
          ),
          trailing: IconButton(
            tooltip: 'Editar objetivo',
            onPressed: () => edit('goal', goal),
            icon: const Icon(Icons.edit_outlined, size: 20),
          ),
        ),
        LinearProgressIndicator(
          value: data.progress(data.goalSteps(goal.id)),
          minHeight: 3,
          borderRadius: BorderRadius.circular(4),
        ),
        const SizedBox(height: 8),
        for (final step in data.goalSteps(goal.id))
          Row(
            children: [
              Checkbox(
                value: step.completedAt != null,
                onChanged: (_) => action(
                  () => store.change(
                    (d) => d.toggleStep(step.id, DateTime.now()),
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  step.title,
                  style: TextStyle(
                    color: step.completedAt != null ? muted : ink,
                    decoration: step.completedAt != null
                        ? TextDecoration.lineThrough
                        : null,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Editar etapa',
                onPressed: () => edit('step', step),
                icon: const Icon(Icons.more_horiz, size: 19),
              ),
            ],
          ),
        TextButton.icon(
          onPressed: () => edit('step', null, goal.id),
          icon: const Icon(Icons.add, size: 18),
          label: const Text('Adicionar etapa'),
        ),
      ],
    ),
  );
  List<Widget> today() {
    final tasks = data.onDay(day);
    return [
      heading(
        dayKey(day) == dayKey(DateTime.now()) ? 'Meu dia.' : 'Seu dia.',
        '${weekdays[day.weekday - 1]}, ${fullDate(day)}',
      ),
      Row(
        children: [
          IconButton(
            tooltip: 'Dia anterior',
            onPressed: () =>
                setState(() => day = day.subtract(const Duration(days: 1))),
            icon: const Icon(Icons.chevron_left),
          ),
          Expanded(
            child: TextButton.icon(
              onPressed: pickDay,
              icon: const Icon(Icons.calendar_month_outlined),
              label: Text(shortDate(day)),
            ),
          ),
          IconButton(
            tooltip: 'Próximo dia',
            onPressed: () =>
                setState(() => day = day.add(const Duration(days: 1))),
            icon: const Icon(Icons.chevron_right),
          ),
        ],
      ),
      const SizedBox(height: 16),
      Glass(
        child: Row(
          children: [
            const Icon(Icons.sunny_snowing, color: amber, size: 32),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                '${tasks.where((t) => t.doneOn(day)).length} de ${tasks.length} concluídos\nCada pequeno passo conta.',
                style: const TextStyle(height: 1.6),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 22),
      if (tasks.isEmpty)
        const EmptyMessage(
          'Espaço para o que importa',
          'Adicione uma tarefa, compromisso ou hábito para este dia.',
        ),
      for (final task in tasks) taskCard(task),
      if (data.overdue(day).isNotEmpty) ...[
        const SizedBox(height: 20),
        const Eyebrow('Pendências anteriores'),
        for (final task in data.overdue(day)) taskCard(task),
      ],
      if (data.tasks.any(
        (t) => t.due == null && t.kind != 'habit' && t.completedAt == null,
      )) ...[
        const Eyebrow('Sem data'),
        for (final task in data.tasks.where(
          (t) => t.due == null && t.kind != 'habit' && t.completedAt == null,
        ))
          taskCard(task),
      ],
      const SizedBox(height: 20),
      PrimaryButton(
        'Adicionar ao meu dia',
        icon: Icons.add,
        onPressed: () => edit('task'),
      ),
    ];
  }

  Widget taskCard(PlanTask task) => Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Glass(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
      radius: 20,
      child: Row(
        children: [
          Checkbox(
            value: task.doneOn(day),
            onChanged: (_) =>
                action(() => store.change((d) => d.toggleTask(task.id, day))),
          ),
          Expanded(
            child: InkWell(
              onTap: () => edit('task', task),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.title,
                      style: TextStyle(
                        fontSize: 16,
                        decoration: task.doneOn(day)
                            ? TextDecoration.lineThrough
                            : null,
                        color: task.doneOn(day) ? muted : ink,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '${task.kind == 'habit'
                          ? 'Hábito diário'
                          : task.kind == 'event'
                          ? 'Compromisso'
                          : task.category} · ${['Baixa', 'Média', 'Alta'][task.priority]}${task.due == null ? '' : ' · ${shortDate(task.due!)} ${timeLabel(task.due!)}'}',
                      style: const TextStyle(fontSize: 11, color: muted),
                    ),
                    if (data.lineage(task) != null)
                      Text(
                        data.lineage(task)!,
                        style: const TextStyle(fontSize: 11, color: amber),
                      ),
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Editar tarefa',
            onPressed: () => edit('task', task),
            icon: const Icon(Icons.chevron_right, size: 18),
          ),
        ],
      ),
    ),
  );
  List<Widget> planning() => [
    heading(
      'Intenção vira\nmovimento.',
      'Organize a semana. Dê direção ao mês.',
    ),
    CalendarDatePicker(
      initialDate: day,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      onDateChanged: (v) => setState(() {
        day = v;
        tab = 0;
      }),
    ),
    const SizedBox(height: 20),
    const Eyebrow('Objetivos'),
    for (final g in data.goals) ...[
      const SizedBox(height: 12),
      Glass(child: goalCard(g)),
    ],
    if (data.goals.isEmpty)
      const EmptyMessage(
        'Um objetivo de cada vez',
        'Planeje uma entrega para sua semana ou seu mês.',
      ),
    const SizedBox(height: 20),
    PrimaryButton(
      'Criar objetivo',
      icon: Icons.add,
      onPressed: () => edit('goal'),
    ),
  ];
  Future<void> pickDay() async {
    final value = await showDatePicker(
      context: context,
      initialDate: day,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (value != null) setState(() => day = value);
  }

  void history() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (c) => SizedBox(
      height: MediaQuery.sizeOf(c).height * .8,
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          heading('Você chegou\naté aqui.', 'Seu histórico de conquistas.'),
          if (data.history.isEmpty)
            const EmptyMessage(
              'Sua história está começando',
              'As tarefas e etapas concluídas aparecem aqui.',
            ),
          for (final h in data.history.reversed)
            ListTile(
              leading: const Icon(Icons.check_circle_outline, color: amber),
              title: Text(h.title),
              subtitle: Text(fullDate(h.date)),
            ),
        ],
      ),
    ),
  );
  void settings() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (c) => SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          heading('Seu ELO.', 'Dados locais. Sem conta e sem assinatura.'),
          const Text(
            'No iPhone: abra o link no Safari, toque em Compartilhar e escolha Adicionar à Tela de Início. Abra o app uma vez com internet antes de usar offline.',
            style: TextStyle(height: 1.6, color: muted),
          ),
          const SizedBox(height: 18),
          PrimaryButton(
            'Exportar backup',
            icon: Icons.download_outlined,
            onPressed: () => action(
              () => saveText(
                'elo-${dayKey(DateTime.now())}.json',
                data.encode(),
                'application/json',
              ),
            ),
          ),
          TextButton.icon(
            onPressed: () => action(() async {
              final file = await openFile(
                acceptedTypeGroups: [
                  const XTypeGroup(
                    label: 'Backup JSON',
                    extensions: ['json'],
                    mimeTypes: ['application/json'],
                  ),
                ],
              );
              if (file == null) return;
              final restored = AppData.decode(await file.readAsString());
              if (await confirm(
                'Substituir os dados atuais por este backup? Exporte uma cópia antes de continuar.',
              )) {
                await store.restore(restored);
              }
            }),
            icon: const Icon(Icons.upload_outlined),
            label: const Text('Importar backup'),
          ),
          TextButton(
            onPressed: () => action(() async {
              final kept = await requestPersistence();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      kept ? 'Armazenamento persistente autorizado.' : 'O navegador gerencia o espaço. Mantenha seus backups.',
                    ),
                  ),
                );
              }
            }),
            child: const Text('Solicitar proteção do armazenamento'),
          ),
          const SizedBox(height: 12),
          const Text(
            'Limpar os dados do navegador pode apagar seus registros. Backups exportados permitem recuperá-los.\n\nLembretes: exporte um compromisso para o Calendário no editor de tarefas. Esta versão web não envia notificações com o app fechado.',
            style: TextStyle(color: muted, height: 1.5),
          ),
          const SizedBox(height: 24),
        ],
      ),
    ),
  );
  Future<void> edit(String type, [Object? item, String? parentId]) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => Editor(
          store: store,
          type: type,
          item: item,
          parentId: parentId,
          day: day,
        ),
      ),
    );
    if (result == true && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Salvo no seu aparelho.')));
    }
  }
}

class Editor extends StatefulWidget {
  final ELOStore store;
  final String type;
  final Object? item;
  final String? parentId;
  final DateTime day;
  const Editor({
    super.key,
    required this.store,
    required this.type,
    this.item,
    this.parentId,
    required this.day,
  });
  @override
  State<Editor> createState() => _EditorState();
}

class _EditorState extends State<Editor> {
  final form = GlobalKey<FormState>();
  late TextEditingController title, notes, category;
  String kind = 'task', period = 'month', link = '';
  int priority = 1;
  DateTime? due;
  bool saving = false;
  String? error;
  String get type => widget.type;
  @override
  void initState() {
    super.initState();
    final item = widget.item;
    title = TextEditingController(
      text: item is PlanTask
          ? item.title
          : item is Dream
          ? item.title
          : item is Goal
          ? item.title
          : item is Milestone
          ? item.title
          : '',
    );
    notes = TextEditingController(
      text: item is PlanTask
          ? item.notes
          : item is Dream
          ? item.why
          : '',
    );
    category = TextEditingController(
      text: item is PlanTask ? item.category : 'Pessoal',
    );
    due = item is PlanTask
        ? item.due
        : item is Goal
        ? item.target
        : widget.day;
    link = item is PlanTask
        ? item.stepId ?? ''
        : item is Goal
        ? item.dreamId ?? widget.parentId ?? ''
        : widget.parentId ?? '';
    if (item is PlanTask) {
      kind = item.kind;
      priority = item.priority;
    }
    if (item is Goal) period = item.period;
  }

  @override
  void dispose() {
    title.dispose();
    notes.dispose();
    category.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    setState(() {
      saving = true;
      error = null;
    });
    try {
      await widget.store.change((d) {
        final item = widget.item;
        final name = cleanTitle(title.text);
        if (type == 'dream') {
          if (item is Dream) {
            final v = d.dreams.firstWhere((v) => v.id == item.id);
            v.title = name;
            v.why = notes.text.trim();
          } else {
            d.dreams.add(Dream(title: name, why: notes.text.trim()));
          }
        } else if (type == 'goal') {
          final v = item is Goal
              ? d.goals.firstWhere((v) => v.id == item.id)
              : Goal(title: name);
          v.title = name;
          v.period = period;
          v.target = due ?? widget.day;
          v.dreamId = link.isEmpty ? null : link;
          if (item == null) d.goals.add(v);
        } else if (type == 'step') {
          if (item is Milestone) {
            d.steps.firstWhere((v) => v.id == item.id).title = name;
          } else {
            d.steps.add(Milestone(title: name, goalId: widget.parentId!));
          }
        } else {
          final v = item is PlanTask
              ? d.tasks.firstWhere((v) => v.id == item.id)
              : PlanTask(title: name);
          v.title = name;
          v.notes = notes.text.trim();
          v.category = category.text.trim();
          v.kind = kind;
          v.priority = priority;
          v.due = due;
          v.stepId = link.isEmpty ? null : link;
          if (item == null) d.tasks.add(v);
        }
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> remove() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Excluir este item?'),
        content: Text(
          type == 'goal'
              ? 'As etapas serão removidas. Suas tarefas e conquistas serão preservadas.'
              : 'Esta ação remove o item. As conquistas registradas permanecem no histórico.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await widget.store.change((d) {
        final item = widget.item;
        if (item is Dream) d.deleteDream(item.id);
        if (item is Goal) d.deleteGoal(item.id);
        if (item is Milestone) d.deleteStep(item.id);
        if (item is PlanTask) d.tasks.removeWhere((v) => v.id == item.id);
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        '${widget.item == null ? 'Novo' : 'Editar'} ${type == 'dream'
            ? 'sonho'
            : type == 'goal'
            ? 'objetivo'
            : type == 'step'
            ? 'passo'
            : 'item'}',
      ),
    ),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 620),
        child: Form(
          key: form,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              TextFormField(
                controller: title,
                autofocus: widget.item == null,
                maxLength: 200,
                decoration: const InputDecoration(labelText: 'Título'),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Escreva um título.' : null,
              ),
              const SizedBox(height: 16),
              if (type == 'dream' || type == 'task') ...[
                TextFormField(
                  controller: notes,
                  maxLines: 3,
                  maxLength: 2000,
                  decoration: InputDecoration(
                    labelText: type == 'dream'
                        ? 'Por que isso importa?'
                        : 'Notas',
                  ),
                ),
                const SizedBox(height: 16),
              ],
              if (type == 'task') ...[
                DropdownButtonFormField<String>(
                  initialValue: kind,
                  decoration: const InputDecoration(labelText: 'Tipo'),
                  items: const [
                    DropdownMenuItem(value: 'task', child: Text('Tarefa')),
                    DropdownMenuItem(
                      value: 'event',
                      child: Text('Compromisso'),
                    ),
                    DropdownMenuItem(
                      value: 'habit',
                      child: Text('Hábito diário'),
                    ),
                  ],
                  onChanged: widget.item == null
                      ? (v) => setState(() => kind = v!)
                      : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int>(
                  initialValue: priority,
                  decoration: const InputDecoration(labelText: 'Prioridade'),
                  items: List.generate(
                    3,
                    (i) => DropdownMenuItem(
                      value: i,
                      child: Text(['Baixa', 'Média', 'Alta'][i]),
                    ),
                  ),
                  onChanged: (v) => setState(() => priority = v!),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: category,
                  maxLength: 80,
                  decoration: const InputDecoration(labelText: 'Categoria'),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  initialValue: link,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Conectar a uma etapa',
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: '',
                      child: Text('Sem vínculo'),
                    ),
                    for (final s in widget.store.data.steps)
                      DropdownMenuItem(
                        value: s.id,
                        child: Text(s.title, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) => setState(() => link = v!),
                ),
                const SizedBox(height: 16),
              ],
              if (type == 'goal') ...[
                DropdownButtonFormField<String>(
                  initialValue: period,
                  decoration: const InputDecoration(labelText: 'Período'),
                  items: const [
                    DropdownMenuItem(value: 'week', child: Text('Semanal')),
                    DropdownMenuItem(value: 'month', child: Text('Mensal')),
                    DropdownMenuItem(value: 'any', child: Text('Longo prazo')),
                  ],
                  onChanged: (v) => setState(() => period = v!),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  initialValue: link,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Sonho'),
                  items: [
                    const DropdownMenuItem(
                      value: '',
                      child: Text('Objetivo independente'),
                    ),
                    for (final d in widget.store.data.dreams)
                      DropdownMenuItem(
                        value: d.id,
                        child: Text(d.title, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) => setState(() => link = v!),
                ),
                const SizedBox(height: 16),
              ],
              if (type == 'task' || type == 'goal') ...[
                OutlinedButton.icon(
                  onPressed: () async {
                    final d = await showDatePicker(
                      context: context,
                      initialDate: due ?? widget.day,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) {
                      setState(
                        () => due = DateTime(
                          d.year,
                          d.month,
                          d.day,
                          due?.hour ?? 9,
                          due?.minute ?? 0,
                        ),
                      );
                    }
                  },
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: Text(due == null ? 'Definir data' : fullDate(due!)),
                ),
                if (type == 'task') ...[
                  OutlinedButton.icon(
                    onPressed: () async {
                      final t = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.fromDateTime(due ?? widget.day),
                      );
                      if (t != null) {
                        setState(() {
                          final d = due ?? widget.day;
                          due = DateTime(
                            d.year,
                            d.month,
                            d.day,
                            t.hour,
                            t.minute,
                          );
                        });
                      }
                    },
                    icon: const Icon(Icons.schedule),
                    label: Text(
                      due == null ? 'Definir horário' : timeLabel(due!),
                    ),
                  ),
                  if (kind != 'event')
                    TextButton(
                      onPressed: () => setState(() => due = null),
                      child: const Text('Sem prazo'),
                    ),
                ],
                const SizedBox(height: 16),
              ],
              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ),
              PrimaryButton(
                saving ? 'Salvando…' : 'Salvar',
                onPressed: saving ? null : save,
              ),
              if (widget.item is PlanTask && due != null)
                TextButton.icon(
                  onPressed: () async {
                    try {
                      await saveText(
                        'elo-compromisso.ics',
                        calendarEvent(
                          PlanTask(
                            title: cleanTitle(title.text),
                            notes: notes.text,
                            due: due,
                          ),
                        ),
                        'text/calendar',
                      );
                    } catch (e) {
                      setState(() => error = e.toString());
                    }
                  },
                  icon: const Icon(Icons.notifications_outlined),
                  label: const Text('Exportar para o Calendário'),
                ),
              if (widget.item != null)
                TextButton(
                  onPressed: saving ? null : remove,
                  child: const Text('Excluir item'),
                ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    ),
  );
}

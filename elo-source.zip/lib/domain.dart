import 'dart:convert';
import 'dart:math';

String newId() =>
    '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}-${Random.secure().nextInt(0x7fffffff).toRadixString(36)}';
String dayKey(DateTime date) =>
    '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
DateTime dayStart(DateTime date) => DateTime(date.year, date.month, date.day);
DateTime monday(DateTime date) =>
    dayStart(date).subtract(Duration(days: date.weekday - 1));
String cleanTitle(String text) {
  final title = text.trim();
  if (title.isEmpty || title.length > 200) {
    throw const FormatException('Use um título entre 1 e 200 caracteres.');
  }
  return title;
}

class Dream {
  String id, title, why;
  Dream({String? id, required this.title, this.why = ''}) : id = id ?? newId();
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'why': why};
  factory Dream.fromJson(Map<String, dynamic> j) => Dream(
    id: j['id'] as String,
    title: j['title'] as String,
    why: j['why'] as String? ?? '',
  );
}

class Goal {
  String id, title, period;
  String? dreamId;
  DateTime target;
  Goal({
    String? id,
    required this.title,
    this.dreamId,
    this.period = 'month',
    DateTime? target,
  }) : id = id ?? newId(),
       target = target ?? DateTime.now();
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'dreamId': dreamId,
    'period': period,
    'target': target.toIso8601String(),
  };
  factory Goal.fromJson(Map<String, dynamic> j) => Goal(
    id: j['id'] as String,
    title: j['title'] as String,
    dreamId: j['dreamId'] as String?,
    period: j['period'] as String,
    target: DateTime.parse(j['target'] as String),
  );
}

class Milestone {
  String id, title, goalId;
  DateTime? completedAt;
  Milestone({
    String? id,
    required this.title,
    required this.goalId,
    this.completedAt,
  }) : id = id ?? newId();
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'goalId': goalId,
    'completedAt': completedAt?.toIso8601String(),
  };
  factory Milestone.fromJson(Map<String, dynamic> j) => Milestone(
    id: j['id'] as String,
    title: j['title'] as String,
    goalId: j['goalId'] as String,
    completedAt: j['completedAt'] == null
        ? null
        : DateTime.parse(j['completedAt'] as String),
  );
}

class PlanTask {
  String id, title, notes, category, kind;
  String? stepId;
  int priority;
  DateTime? due, completedAt;
  DateTime createdAt;
  List<String> checkIns;
  PlanTask({
    String? id,
    required this.title,
    this.notes = '',
    this.category = 'Pessoal',
    this.kind = 'task',
    this.stepId,
    this.priority = 1,
    this.due,
    this.completedAt,
    DateTime? createdAt,
    List<String>? checkIns,
  }) : id = id ?? newId(),
       createdAt = createdAt ?? DateTime.now(),
       checkIns = checkIns ?? [];
  bool doneOn(DateTime day) =>
      kind == 'habit' ? checkIns.contains(dayKey(day)) : completedAt != null;
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'notes': notes,
    'category': category,
    'kind': kind,
    'stepId': stepId,
    'priority': priority,
    'due': due?.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
    'checkIns': checkIns,
  };
  factory PlanTask.fromJson(Map<String, dynamic> j) => PlanTask(
    id: j['id'] as String,
    title: j['title'] as String,
    notes: j['notes'] as String? ?? '',
    category: j['category'] as String? ?? 'Pessoal',
    kind: j['kind'] as String? ?? 'task',
    stepId: j['stepId'] as String?,
    priority: j['priority'] as int? ?? 1,
    due: j['due'] == null ? null : DateTime.parse(j['due'] as String),
    completedAt: j['completedAt'] == null
        ? null
        : DateTime.parse(j['completedAt'] as String),
    createdAt: DateTime.parse(j['createdAt'] as String),
    checkIns: List<String>.from(j['checkIns'] as List? ?? []),
  );
}

class Achievement {
  String id, sourceId, title, kind;
  DateTime date;
  Achievement({
    String? id,
    required this.sourceId,
    required this.title,
    required this.kind,
    required this.date,
  }) : id = id ?? newId();
  Map<String, dynamic> toJson() => {
    'id': id,
    'sourceId': sourceId,
    'title': title,
    'kind': kind,
    'date': date.toIso8601String(),
  };
  factory Achievement.fromJson(Map<String, dynamic> j) => Achievement(
    id: j['id'] as String,
    sourceId: j['sourceId'] as String,
    title: j['title'] as String,
    kind: j['kind'] as String,
    date: DateTime.parse(j['date'] as String),
  );
}

class AppData {
  int version;
  bool started;
  List<Dream> dreams;
  List<Goal> goals;
  List<Milestone> steps;
  List<PlanTask> tasks;
  List<Achievement> history;
  AppData({
    this.version = 1,
    this.started = false,
    List<Dream>? dreams,
    List<Goal>? goals,
    List<Milestone>? steps,
    List<PlanTask>? tasks,
    List<Achievement>? history,
  }) : dreams = dreams ?? [],
       goals = goals ?? [],
       steps = steps ?? [],
       tasks = tasks ?? [],
       history = history ?? [];

  Map<String, dynamic> toJson() => {
    'format': 'elo.flutter',
    'version': version,
    'started': started,
    'dreams': dreams.map((v) => v.toJson()).toList(),
    'goals': goals.map((v) => v.toJson()).toList(),
    'steps': steps.map((v) => v.toJson()).toList(),
    'tasks': tasks.map((v) => v.toJson()).toList(),
    'history': history.map((v) => v.toJson()).toList(),
  };
  String encode() => jsonEncode(toJson());
  AppData clone() => AppData.decode(encode());
  factory AppData.decode(String raw) {
    if (raw.length > 10000000) {
      throw const FormatException('O backup excede 10 MB.');
    }
    final j = jsonDecode(raw) as Map<String, dynamic>;
    if (j['version'] != 1 || j['format'] != 'elo.flutter') {
      throw const FormatException(
        'Este arquivo não é um backup compatível do ELO Flutter.',
      );
    }
    final data = AppData(
      version: j['version'] as int,
      started: j['started'] as bool,
      dreams: (j['dreams'] as List)
          .map((v) => Dream.fromJson(v as Map<String, dynamic>))
          .toList(),
      goals: (j['goals'] as List)
          .map((v) => Goal.fromJson(v as Map<String, dynamic>))
          .toList(),
      steps: (j['steps'] as List)
          .map((v) => Milestone.fromJson(v as Map<String, dynamic>))
          .toList(),
      tasks: (j['tasks'] as List)
          .map((v) => PlanTask.fromJson(v as Map<String, dynamic>))
          .toList(),
      history: (j['history'] as List)
          .map((v) => Achievement.fromJson(v as Map<String, dynamic>))
          .toList(),
    );
    data.validate();
    return data;
  }
  void validate() {
    if (version != 1) {
      throw const FormatException('Versão de dados incompatível.');
    }
    final ids = [
      ...dreams.map((v) => v.id),
      ...goals.map((v) => v.id),
      ...steps.map((v) => v.id),
      ...tasks.map((v) => v.id),
      ...history.map((v) => v.id),
    ];
    if (ids.toSet().length != ids.length || ids.any((v) => v.isEmpty)) {
      throw const FormatException('O backup contém identificadores inválidos.');
    }
    for (final title in [
      ...dreams.map((v) => v.title),
      ...goals.map((v) => v.title),
      ...steps.map((v) => v.title),
      ...tasks.map((v) => v.title),
    ]) {
      cleanTitle(title);
    }
    final dreamIds = dreams.map((v) => v.id).toSet();
    final goalIds = goals.map((v) => v.id).toSet();
    final stepIds = steps.map((v) => v.id).toSet();
    if (goals.any(
          (v) =>
              (v.dreamId != null && !dreamIds.contains(v.dreamId)) ||
              !['week', 'month', 'any'].contains(v.period),
        ) ||
        steps.any((v) => !goalIds.contains(v.goalId)) ||
        tasks.any(
          (v) =>
              (v.stepId != null && !stepIds.contains(v.stepId)) ||
              !['task', 'event', 'habit'].contains(v.kind) ||
              v.priority < 0 ||
              v.priority > 2 ||
              (v.kind == 'event' && v.due == null),
        )) {
      throw const FormatException('Há dados ou vínculos inválidos no backup.');
    }
  }

  List<Milestone> goalSteps(String id) =>
      steps.where((v) => v.goalId == id).toList();
  List<Milestone> dreamSteps(String id) {
    final ids = goals.where((v) => v.dreamId == id).map((v) => v.id).toSet();
    return steps.where((v) => ids.contains(v.goalId)).toList();
  }

  double progress(List<Milestone> values) => values.isEmpty
      ? 0
      : values.where((v) => v.completedAt != null).length / values.length;
  List<PlanTask> onDay(DateTime day) {
    final values = tasks
        .where(
          (v) => v.kind == 'habit'
              ? !dayStart(v.due ?? v.createdAt).isAfter(dayStart(day))
              : v.due != null && dayKey(v.due!) == dayKey(day),
        )
        .toList();
    values.sort((a, b) {
      if (a.doneOn(day) != b.doneOn(day)) return a.doneOn(day) ? 1 : -1;
      final p = b.priority.compareTo(a.priority);
      return p == 0
          ? (a.due ?? a.createdAt).compareTo(b.due ?? b.createdAt)
          : p;
    });
    return values;
  }

  List<PlanTask> overdue(DateTime day) => tasks
      .where(
        (v) =>
            v.kind != 'habit' &&
            v.completedAt == null &&
            v.due != null &&
            v.due!.isBefore(dayStart(day)),
      )
      .toList();
  String? lineage(PlanTask task) {
    final step = steps.where((v) => v.id == task.stepId).firstOrNull;
    if (step == null) return null;
    final goal = goals.where((v) => v.id == step.goalId).firstOrNull;
    final dream = dreams.where((v) => v.id == goal?.dreamId).firstOrNull;
    return dream == null ? goal?.title : '${goal!.title} → ${dream.title}';
  }

  void toggleTask(String id, DateTime day) {
    final task = tasks.firstWhere((v) => v.id == id);
    final wasDone = task.doneOn(day);
    if (task.kind == 'habit') {
      if (wasDone) {
        task.checkIns.remove(dayKey(day));
      } else {
        task.checkIns.add(dayKey(day));
      }
    } else {
      task.completedAt = wasDone ? null : day;
    }
    if (wasDone) {
      history.removeWhere(
        (v) =>
            v.sourceId == id &&
            (task.kind != 'habit' || dayKey(v.date) == dayKey(day)),
      );
    } else {
      history.add(
        Achievement(
          sourceId: id,
          title: task.title,
          kind: task.kind,
          date: day,
        ),
      );
    }
  }

  void toggleStep(String id, DateTime now) {
    final step = steps.firstWhere((v) => v.id == id);
    if (step.completedAt == null) {
      step.completedAt = now;
      history.add(
        Achievement(sourceId: id, title: step.title, kind: 'step', date: now),
      );
    } else {
      step.completedAt = null;
      history.removeWhere((v) => v.sourceId == id);
    }
  }

  void deleteStep(String id) {
    steps.removeWhere((v) => v.id == id);
    for (final task in tasks.where((v) => v.stepId == id)) {
      task.stepId = null;
    }
  }

  void deleteGoal(String id) {
    for (final step in goalSteps(id)) {
      deleteStep(step.id);
    }
    goals.removeWhere((v) => v.id == id);
  }

  void deleteDream(String id) {
    dreams.removeWhere((v) => v.id == id);
    for (final goal in goals.where((v) => v.dreamId == id)) {
      goal.dreamId = null;
    }
  }

  factory AppData.demo([DateTime? date]) {
    final now = date ?? DateTime.now();
    final dream = Dream(
      title: 'Vaga como Product Owner',
      why: 'Um sonho. Pequenos passos reais.',
    );
    final goal = Goal(
      title: 'Construir meu portfólio',
      dreamId: dream.id,
      target: now,
    );
    final steps = [
      Milestone(
        title: 'Definir meu posicionamento',
        goalId: goal.id,
        completedAt: now,
      ),
      Milestone(title: 'Construir meu portfólio', goalId: goal.id),
      Milestone(title: 'Publicar meu primeiro aplicativo', goalId: goal.id),
      Milestone(title: 'Apresentar meu estudo de caso', goalId: goal.id),
    ];
    return AppData(
      started: true,
      dreams: [dream],
      goals: [goal],
      steps: steps,
      tasks: [
        PlanTask(
          title: 'Desenhar a tela inicial',
          stepId: steps[1].id,
          priority: 2,
          category: 'Carreira',
          due: DateTime(now.year, now.month, now.day, 14),
        ),
        PlanTask(
          title: 'Revisar meu portfólio',
          category: 'Carreira',
          due: now,
        ),
        PlanTask(
          title: 'Ler por 20 minutos',
          kind: 'habit',
          category: 'Aprendizado',
          createdAt: now,
        ),
      ],
      history: [
        Achievement(
          sourceId: steps[0].id,
          title: steps[0].title,
          kind: 'step',
          date: now,
        ),
      ],
    );
  }
}

String calendarEvent(PlanTask task) {
  if (task.due == null) {
    throw const FormatException('Defina data e horário primeiro.');
  }
  String stamp(DateTime v) =>
      '${v.toUtc().toIso8601String().replaceAll(RegExp(r'[-:]'), '').split('.').first.replaceAll('Z', '')}Z';
  String escape(String v) => v
      .replaceAll('\\', '\\\\')
      .replaceAll('\r', '')
      .replaceAll('\n', r'\n')
      .replaceAll(',', r'\,')
      .replaceAll(';', r'\;');
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ELO//Organizador//PT-BR',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    'UID:${task.id}@elo',
    'DTSTAMP:${stamp(DateTime.now())}',
    'DTSTART:${stamp(task.due!)}',
    'DTEND:${stamp(task.due!.add(const Duration(minutes: 30)))}',
    'SUMMARY:${escape(task.title)}',
    'DESCRIPTION:${escape(task.notes)}',
    'BEGIN:VALARM',
    'TRIGGER:PT0M',
    'ACTION:DISPLAY',
    'DESCRIPTION:${escape(task.title)}',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
    '',
  ].join('\r\n');
}

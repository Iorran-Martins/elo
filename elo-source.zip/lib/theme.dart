import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

const bg = Color(0xff100e0c);
const surface = Color(0xff211c17);
const amber = Color(0xfff9c07b);
const ink = Color(0xfff7f1e5);
const muted = Color(0xffb5ad9f);

ThemeData eloTheme() => ThemeData(
  brightness: Brightness.dark,
  useMaterial3: true,
  scaffoldBackgroundColor: bg,
  fontFamily: 'EloSans',
  colorScheme: const ColorScheme.dark(
    primary: amber,
    secondary: amber,
    surface: surface,
    onSurface: ink,
    onPrimary: bg,
    error: Color(0xffffad9e),
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: bg,
    foregroundColor: ink,
    elevation: 0,
    centerTitle: false,
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: surface,
    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(18),
      borderSide: const BorderSide(color: Color(0xff514332)),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(18),
      borderSide: const BorderSide(color: Color(0xff514332)),
    ),
  ),
  snackBarTheme: const SnackBarThemeData(
    backgroundColor: Color(0xff3d3123),
    contentTextStyle: TextStyle(color: ink),
    behavior: SnackBarBehavior.floating,
  ),
  dialogTheme: const DialogThemeData(backgroundColor: surface),
  dividerTheme: const DividerThemeData(
    color: Color(0xff3c3329),
    thickness: 0.6,
  ),
);

class Glass extends StatelessWidget {
  final Widget child;
  final bool active;
  final EdgeInsets padding;
  final double radius;
  const Glass({
    super.key,
    required this.child,
    this.active = false,
    this.padding = const EdgeInsets.all(20),
    this.radius = 26,
  });
  @override
  Widget build(BuildContext context) {
    final accessible =
        MediaQuery.highContrastOf(context) ||
        MediaQuery.disableAnimationsOf(context);
    final panel = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active
              ? [const Color(0x664e3821), const Color(0x33322b22)]
              : [const Color(0x553e382f), const Color(0x44211c17)],
        ),
        color: accessible ? surface : null,
        border: Border.all(
          color: active
              ? amber.withValues(alpha: 0.55)
              : ink.withValues(alpha: 0.17),
        ),
      ),
      child: child,
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: accessible
          ? panel
          : BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
              child: panel,
            ),
    );
  }
}

class Eyebrow extends StatelessWidget {
  final String text;
  const Eyebrow(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(
    text.toUpperCase(),
    style: const TextStyle(
      fontSize: 11,
      letterSpacing: 3.0,
      fontWeight: FontWeight.w500,
      color: amber,
    ),
  );
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  const PrimaryButton(this.label, {super.key, this.onPressed, this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    child: FilledButton(
      style: FilledButton.styleFrom(
        backgroundColor: amber,
        foregroundColor: bg,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
        minimumSize: const Size(0, 56),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ),
          if (icon != null) ...[
            const SizedBox(width: 14),
            Icon(icon, size: 21),
          ],
        ],
      ),
    ),
  );
}

class EmptyMessage extends StatelessWidget {
  final String title, message;
  final IconData icon;
  const EmptyMessage(
    this.title,
    this.message, {
    super.key,
    this.icon = Icons.auto_awesome_outlined,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
    child: Column(
      children: [
        Icon(icon, color: amber, size: 34),
        const SizedBox(height: 16),
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 19),
        ),
        const SizedBox(height: 9),
        Text(
          message,
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted, height: 1.5),
        ),
      ],
    ),
  );
}

class Horizon extends StatelessWidget {
  final double progress;
  const Horizon(this.progress, {super.key});
  @override
  Widget build(BuildContext context) => Semantics(
    label: 'Progresso do sonho: ${(progress * 100).round()} por cento',
    child: ExcludeSemantics(
      child: SizedBox(
        height: 222,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned.fill(
              child: ShaderMask(
                blendMode: BlendMode.dstIn,
                shaderCallback: (bounds) => const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black,
                    Colors.black,
                    Colors.transparent,
                  ],
                  stops: [0, 0.18, 0.75, 1],
                ).createShader(bounds),
                child: Image.asset('assets/horizon.png', fit: BoxFit.cover),
              ),
            ),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: progress),
              duration: MediaQuery.disableAnimationsOf(context)
                  ? Duration.zero
                  : const Duration(milliseconds: 650),
              curve: Curves.easeOutCubic,
              builder: (context, value, _) => SizedBox(
                width: 186,
                height: 186,
                child: CustomPaint(painter: _HorizonProgress(value)),
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${(progress * 100).round()}%',
                  style: const TextStyle(
                    fontSize: 43,
                    fontWeight: FontWeight.w300,
                    color: ink,
                  ),
                ),
                const Text(
                  'do caminho',
                  style: TextStyle(fontSize: 12, letterSpacing: 2, color: ink),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

const monthNames = [
  'janeiro',
  'fevereiro',
  'março',
  'abril',
  'maio',
  'junho',
  'julho',
  'agosto',
  'setembro',
  'outubro',
  'novembro',
  'dezembro',
];
const weekdays = [
  'segunda',
  'terça',
  'quarta',
  'quinta',
  'sexta',
  'sábado',
  'domingo',
];
String shortDate(DateTime d) =>
    '${d.day} ${monthNames[d.month - 1].substring(0, 3)}';
String fullDate(DateTime d) =>
    '${d.day} de ${monthNames[d.month - 1]} de ${d.year}';
String timeLabel(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

class _HorizonProgress extends CustomPainter {
  final double value;
  _HorizonProgress(this.value);
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(5, 8, size.width - 10, size.height - 10);
    const start = math.pi * .94, sweep = math.pi * 1.12;
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..strokeCap = StrokeCap.round
      ..color = const Color(0x665e4930);
    canvas.drawArc(rect, start, sweep, false, base);
    canvas.drawArc(
      rect.inflate(7),
      start,
      sweep,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = const Color(0x88e5ceb0),
    );
    if (value > 0) {
      canvas.drawArc(
        rect,
        start,
        sweep * value,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 22
          ..strokeCap = StrokeCap.round
          ..color = amber.withValues(alpha: .35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9),
      );
      canvas.drawArc(
        rect,
        start,
        sweep * value,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 15
          ..strokeCap = StrokeCap.round
          ..shader = const LinearGradient(
            colors: [Color(0xffc08443), Color(0xffffd99c), Color(0xffffedcf)],
          ).createShader(rect),
      );
      canvas.drawArc(
        rect.deflate(6),
        start,
        sweep * value,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = const Color(0xffffe6be),
      );
    }
  }

  @override
  bool shouldRepaint(_HorizonProgress old) => old.value != value;
}

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'domain.dart';

abstract class DataStorage {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
}

class PreferencesStorage implements DataStorage {
  final SharedPreferencesAsync preferences = SharedPreferencesAsync();
  @override
  Future<String?> read(String key) => preferences.getString(key);
  @override
  Future<void> write(String key, String value) =>
      preferences.setString(key, value);
}

class ELOStore extends ChangeNotifier {
  static const dataKey = 'elo.flutter.v1.data';
  static const backupKey = 'elo.flutter.v1.backup';
  final DataStorage storage;
  AppData data = AppData();
  bool loading = true, busy = false;
  String? loadError;
  String? _baseline;
  ELOStore(this.storage);

  Future<void> load() async {
    loading = true;
    notifyListeners();
    try {
      final raw = await storage.read(dataKey);
      final next = raw == null ? AppData() : AppData.decode(raw);
      data = next;
      _baseline = raw;
      loadError = null;
    } catch (_) {
      loadError = 'Seus dados não puderam ser abertos. O conteúdo original foi preservado. Tente a cópia de recuperação ou exporte o arquivo original.';
    }
    loading = false;
    notifyListeners();
  }

  Future<void> change(void Function(AppData next) mutation) async {
    if (loadError != null) {
      throw StateError('Recupere seus dados antes de continuar.');
    }
    if (busy) throw StateError('Aguarde o salvamento anterior.');
    busy = true;
    notifyListeners();
    try {
      final current = await storage.read(dataKey);
      if (current != _baseline) {
        throw StateError(
          'Os dados mudaram em outra janela. Reabra o app antes de salvar para evitar perder alterações.',
        );
      }
      final next = data.clone();
      mutation(next);
      next.validate();
      final raw = next.encode();
      if (raw.length > 4000000) {
        throw StateError(
          'Seu arquivo ficou grande. Exporte um backup antes de continuar.',
        );
      }
      if (current != null) await storage.write(backupKey, current);
      await storage.write(dataKey, raw);
      _baseline = raw;
      data = next;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> recover() async {
    final backup = await storage.read(backupKey);
    if (backup == null) {
      throw StateError('Ainda não há uma cópia de recuperação.');
    }
    final next = AppData.decode(backup);
    final current = await storage.read(dataKey);
    if (current != null) {
      await storage.write(
        'elo.flutter.recovery.${DateTime.now().millisecondsSinceEpoch}',
        current,
      );
    }
    await storage.write(dataKey, backup);
    data = next;
    _baseline = backup;
    loadError = null;
    notifyListeners();
  }

  Future<String?> original() => storage.read(dataKey);
  Future<void> restore(AppData value) => change((next) {
    next.started = value.started;
    next.dreams = value.dreams;
    next.goals = value.goals;
    next.steps = value.steps;
    next.tasks = value.tasks;
    next.history = value.history;
  });
}
